# ClipViral AI — Browser Starter

## Cara mencoba di komputer
1. Ekstrak ZIP.
2. Buka `index.html` menggunakan Google Chrome atau Microsoft Edge.
3. Upload video, pilih durasi dan gaya, lalu klik **Buat kandidat klip**.
4. Gunakan **Preview** untuk melihat bagian video dan **Export** untuk mencoba ekspor WebM.

## Cara memasang di GitHub Pages
1. Buka https://github.com/new lalu buat repository bernama `clipviral-ai`.
2. Pilih Public (atau sesuaikan kebutuhan), lalu Create repository.
3. Klik **Add file → Upload files** dan upload `index.html` (README boleh ikut diupload).
4. Klik **Commit changes**.
5. Buka **Settings → Pages**.
6. Pada **Build and deployment**, pilih **Deploy from a branch**.
7. Pilih branch `main`, folder `/(root)`, lalu klik **Save**.
8. Tunggu sampai Pages selesai menerbitkan situs. URL biasanya:
   `https://USERNAME.github.io/clipviral-ai/`

## Batasan versi ini
- Ini adalah prototipe frontend statis, bukan AI video editor penuh.
- Kandidat dibuat dengan membagi durasi video; tidak menganalisis isi video untuk menemukan momen viral.
- Subtitle otomatis, deteksi momen AI, crop/reframe otomatis, akun pengguna, penyimpanan proyek permanen, dan backend FFmpeg belum diintegrasikan.
- Ekspor browser menggunakan MediaRecorder dan dapat menghasilkan WebM; dukungan tergantung browser/codec. Untuk ekspor yang stabil dan pemrosesan AI, tambahkan backend seperti FastAPI + FFmpeg + model transkripsi/analisis.
- File video diproses di browser untuk preview. Jangan unggah video sensitif ke layanan publik.

## Struktur
- `index.html` — aplikasi web frontend.
- `README.md` — panduan ini.
